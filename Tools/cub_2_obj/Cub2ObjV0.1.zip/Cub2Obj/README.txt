Cub2Obj is a simple program designed to convert the Cube-World model files (.cub) to WaveFront model files (.obj & .mtl), for modeling / animating purposes.

Feel free to use this. Any Questions to 'TheMcJabbar' or 40BlocksUnder@gmail.com.

Happy Animating! 